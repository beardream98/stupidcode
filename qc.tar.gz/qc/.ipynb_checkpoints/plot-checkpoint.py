# -*- coding: utf-8 -*-
# +
# -*- coding: utf-8 -*-
import yaml
import data
from data.read_data_temp import select_data,TrainData,file_split,DataByFile,sample_negative
from data.data_split import kfsplit
from data.datasets import prepare_loaders
from utils.wandb_init import get_run,wandb_utils
from utils.train import get_score,train_set,get_score_list
from utils.trivial import get_logger
from model.head import OriginModel
from model.trainer import train,predict
import torch
from transformers import logging

import wandb

import numpy as np
import pandas as pd 
import os
import torch

from sklearn.metrics import precision_score,recall_score,f1_score
import gc 
gc.enable()
from utils.trivial import set_seed

import warnings
from pandas.core.common import SettingWithCopyWarning
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)


# +
yaml_path="./config/train.yaml"
CONFIG,Logger,DEVICE=train_set(yaml_path,experimentName=None,upload=False,filename="./test/logs",is_notebook=False)

CONFIG["num_hidden_layers"]=12
CONFIG["DATA_NUM"]=5000
CONFIG["EPOCHS"]=1
CONFIG["DEBUG_MODEL"]=False
CONFIG["run_db"]=False
# -

CONFIG["INPUT_DIR"]="/vc_data/users/v-mxiong/qc/QueryTitle05"
with open(os.path.join(CONFIG["INPUT_DIR"],"Schema"),"r") as f:
    line=f.readlines()[0].strip()
    column_name=line.split("\t")
    CONFIG["Logger"].info(f"column_name :{column_name}")

# +

from data.read_data_temp import read_data_file
positivepath=os.path.join(CONFIG["INPUT_DIR"],"positivefold")
data_type="test"
# deperate the last uncomplete negative file

positive_file=os.path.join(positivepath,data_type)
positive_df=read_data_file(positive_file,CONFIG["DEBUG_MODEL"],data_num=CONFIG["DATA_NUM"],head=column_name)

positive_df["label"]=positive_df["label"].replace(["0","1"],[0,1])
positive_df=positive_df.query("label==1 or label==0")
positive_df["label"]=positive_df["label"].astype(int)
positive_df.reset_index(inplace=True,drop=True)


# +

input_file=os.path.join(CONFIG["INPUT_DIR"],"NegativeTest")

negative_df=read_data_file(input_file,CONFIG["DEBUG_MODEL"],data_num=CONFIG["DATA_NUM"],head=column_name)
negative_df["label"]=negative_df["label"].replace(["0","1"],[0,1])
negative_df=negative_df.query("label==1 or label==0")
negative_df["label"]=negative_df["label"].astype(int)
negative_df.reset_index(inplace=True,drop=True)


# -

negative_df["dsat"]=negative_df["dsat"].replace(["0","1"],[0,1])
negative_df=negative_df.query("dsat==1 or dsat==0")
negative_df["dsat"]=negative_df["dsat"].astype(int)
negative_df.reset_index(inplace=True,drop=True)


print(negative_df["dsat"].value_counts())

# +
dsat_df,unclick_df=negative_df.query("dsat==1"),negative_df.query("dsat==0")

dsat_df.reset_index(inplace=True,drop=True)
unclick_df.reset_index(inplace=True,drop=True)

test_df=pd.concat([positive_df,dsat_df],axis=0)
test_df=test_df.sample(frac=1).reset_index(drop=True)
test_df=sample_negative(test_df)

print(test_df["label"].value_counts())
# -

from query_baseline import test_floop
CONFIG["SAVE_PATH"]="./checkpoint/handlesave/querytitlebest"
result_df=test_floop(CONFIG,test_df,DEVICE)


y_true,y_scores=result_df["label"],result_df["prob1"]

# +

import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve, average_precision_score
 
'''
y_true: 
  类型：np.array； gt标签
y_scores：
  类型：np.array； 由大至小排序的阈值score,
'''
#画曲线
precision, recall, thresholds = precision_recall_curve(y_true, y_scores)
plt.figure("P-R Curve")
plt.title('Precision/Recall Curve')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.plot(recall,precision)

AP = average_precision_score(y_true, y_scores, average='macro', pos_label=1, sample_weight=None)
print('AP:', AP)
