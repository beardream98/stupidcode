import numpy as np
import pandas as pd 
import os
import random
import time
from tqdm import tqdm
import copy

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast as autocast, GradScaler
from transformers import AutoConfig, AutoModel, AutoTokenizer, AdamW, get_linear_schedule_with_warmup, logging


class OriginModel(nn.Module):
    def __init__(self,CONFIG,is_embedding=False):
        super(OriginModel,self).__init__()
        model_name=CONFIG["model_name"]
        self.config=AutoConfig.from_pretrained(model_name)
        self.config.update({"num_hidden_layers":CONFIG["num_hidden_layers"]})
        self.model=AutoModel.from_pretrained(model_name,config=self.config)
        self.drop=nn.Dropout(p=CONFIG["dropout_rate"])
        self.is_embedding=is_embedding
        self.linear=nn.Linear(self.config.to_dict()["hidden_size"],2)
           
        self.dense = nn.Linear(self.config.to_dict()["hidden_size"], self.config.to_dict()["hidden_size"])
        self.activation = nn.Tanh()
        self.loss_fn = torch.nn.CrossEntropyLoss()
    
    def forward(self,input_ids,attention_mask,labels=None):
        out=self.model(input_ids=input_ids,attention_mask=attention_mask,output_hidden_states=False)
        last_hidden_state = out[0]
        cls_embeddings = last_hidden_state[:,0]
#         pooled_output = self.dense(cls_embeddings)
#         pooled_output = self.activation(pooled_output)
        
#         out=self.drop(pooled_output)
        if self.is_embedding:
            return cls_embeddings
            
        out=self.drop(cls_embeddings)
        outputs=self.linear(out)
        preds=outputs.squeeze(1)

        
        if labels!=None:
            loss=self.loss_fn(preds,labels)
            return loss
        else:
            return preds

if __name__=='__main__':
    pass